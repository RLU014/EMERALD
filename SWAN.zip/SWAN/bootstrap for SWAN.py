#!/usr/bin/env python
# coding: utf-8

# In[74]:


from patsy import dmatrix
from scipy import stats
import numpy as np
import pandas as pd
import random
import time
import json
import matplotlib.pyplot as plt
#get_ipython().run_line_magic('matplotlib', 'inline')

np.set_printoptions(precision = 4)


# ## fun_df2dict

# In[75]:


def fun_df2dict(data):
    """ Transformation SINGLE variable dataframe into dictionary data 
        structures.
    
    data: pd.dataframe
        The dataframe data structure about single vairable and has 
        three columns,
            $1th columns is the subject ID
            $2nd columns is the time point
            $3rd columns is the observation value correspondent time 
             point at the 2nd columns
    
    return: dict(int: np.array)
        The nested dictionary about df, 
            $The dictionary key is subject ID, 
            $1th inner dictionary key is the vth variable
            $2nd inner dictionary has two key are about variable time 
            and obserivation value 
"""
    
    out = data.groupby(data.columns[0]).apply(lambda dfg: 
                                              dfg.drop(data.columns[0], 
                                                       axis=1).values)
    return out.to_dict()


# ## fun_diag_blocks

# In[76]:


def fun_diag_blocks(data):
    """
    data: list[list[list]/pd.Dataframe/np.2darray]
    
    return: np.2d_array
""" 
    
    A = data[0]
    for v in range(1, len(data)):
        B = data[v]
        
        # Create off-diagonal zeros array
        Azeros = np.zeros((np.shape(A)[0], np.shape(B)[1]), dtype = float)
        Bzeros = np.zeros((np.shape(B)[0], np.shape(A)[1]), dtype = float)
        
        # combine A and B matrix to be new diagonal matrix
        A = np.asarray(np.bmat([[A, Azeros], [Bzeros, B]]))
        
    return A


# #### Orthogonal

# In[77]:


def fun_b_t_N_orth_b_t(n_spline):
    
    t = np.linspace(0, 1, 1000)
    list_knots = np.arange(1, n_spline - 3) / (n_spline - 3) 
    b_t = dmatrix("bs(x = t, knots = list_knots, include_intercept = True,                    lower_bound = 0, upper_bound = 1) - 1")
    J = np.dot(b_t.T, b_t) / 1000
    eigenvalues, eigenvectors = np.linalg.eig(J)
    orth_b_t = np.dot(eigenvectors, np.diag(eigenvalues ** (- 1 / 2)))
    
    return b_t, orth_b_t




# In[79]:


def fun_orth_basis(data_basis, data_orth_b_t):
    
    out = []
    for i in range(len(data_basis)):
        orth_basis = np.dot(data_basis[i], data_orth_b_t)
        out.append(orth_basis)
        
    return out


# ### $\Theta_\mu$: list_theta_mu

# #### fun_theta_mu

# In[80]:


def fun_theta_mu(data_basis, data_original_theta_mu):
    out = []
    for v in range(len(data_original_theta_mu)):
        out.append(np.dot(np.linalg.inv(np.dot(data_basis[v].T, 
                                               data_basis[v])), 
                          np.dot(data_basis[v].T, 
                                 data_original_theta_mu[v])))
    return out


# ### $\Theta_\psi$: list_theta_psi

# #### fun_theta_psi

# In[81]:


def fun_theta_psi(data_orth_basis, data_original_theta_psi, data_sigma, 
                  data_pick_n_pc):
    out = []
    dx = len(data_original_theta_psi)
    
    for v in range(dx):
        initial_psi = np.dot(np.linalg.inv(np.dot(data_orth_basis[v].T, 
                                                  data_orth_basis[v])), 
                             np.dot(data_orth_basis[v].T, 
                                    data_original_theta_psi[v]))
        pick_n_pc = data_pick_n_pc[v]
        matrix_D = np.dot(np.dot(initial_psi[:, :pick_n_pc], 
                                 data_sigma[:pick_n_pc, :pick_n_pc]), 
                          initial_psi[:, :pick_n_pc].T)
        
        data_sigma = data_sigma[pick_n_pc:, pick_n_pc:]
        
        out.append(np.linalg.eigh(matrix_D)[1][:, -pick_n_pc:].T[::-1].T)
        
    return out


# ## $B_{iv}$: fun_matrix_B_iv

# In[82]:


def fun_matrix_B_iv(n, dx, data_id, data_W, data_orth_b_t):
    out = []
    for i in range(n):
        id_i = data_id[i]
        list_B_iv = []
        for v in range(dx):
            t = data_W[v][id_i][:, 0]
            q = len(data_orth_b_t[v])
            list_knots = np.arange(1, q - 3) / (q - 3)
            B_t_iv = dmatrix("bs(x = t, knots = list_knots,                              include_intercept = True,                              lower_bound = 0, upper_bound = 1) - 1")
            list_B_iv.append(np.dot(B_t_iv, data_orth_b_t))
        out.append(list_B_iv)
    return out


def fun_matrix_unorth_B_iv(n, dx, data_id, data_W, data_orth_b_t):
    out = []
    for i in range(n):
        id_i = data_id[i]
        list_B_iv = []
        for v in range(dx):
            t = data_W[v][id_i][:, 0]
            q = len(data_orth_b_t[v])
            list_knots = np.arange(1, q - 3) / (q - 3)
            B_t_iv = dmatrix("bs(x = t, knots = list_knots, \
                             include_intercept = True, \
                             lower_bound = 0, upper_bound = 1) - 1")
            list_B_iv.append(B_t_iv)
        out.append(list_B_iv)
    return out


# ### $\tilde{\mu}_{iv}$: fun_matrix_tilde_mu_iv

# In[83]:


def fun_matrix_tilde_mu_iv(n, dx, data_theta_mu, data_B_unorth_iv):
    out = []
    for i in range(n):
        B_i = data_B_unorth_iv[i]
        list_tilde_mu_iv = []
        for v in range(dx):
            B_iv = B_i[v]
            tilde_mu_iv = np.dot(B_iv, data_theta_mu[v])
            list_tilde_mu_iv.append(tilde_mu_iv)
        out.append(list_tilde_mu_iv)
    return out


# ### $\tilde{\Psi}_{iv}$: fun_matrix_tilde_psi_iv

# In[84]:


def fun_matrix_tilde_psi_iv(n, dx, data_theta_psi, data_B_iv):
    out = []
    for i in range(n):
        B_i = data_B_iv[i]
        list_tilde_psi_iv = []
        for v in range(dx):
            B_iv = B_i[v]
            tilde_psi_iv = np.dot(B_iv, data_theta_psi[v])
            list_tilde_psi_iv.append(tilde_psi_iv)
        out.append(list_tilde_psi_iv)
    return out


# ## $B^*_{iv}$: fun_matrix_B_star_iv

# In[85]:


def fun_matrix_B_star_iv(n, dx, data_id, data_Y, data_orth_b_t):
    out = []
    for i in range(n):
        id_i = data_id[i]
        t = data_Y[id_i][:, 0]
        list_B_star_iv = []
        for v in range(dx):
            q = len(data_orth_b_t[v])
            list_knots = np.arange(1, q - 3) / (q - 3)
            B_star_t_iv = dmatrix("bs(x = t, knots = list_knots,                                   include_intercept = True,                                   lower_bound = 0, upper_bound = 1) - 1")
            list_B_star_iv.append(np.dot(B_star_t_iv, data_orth_b_t))
        out.append(list_B_star_iv)
    return out


def fun_matrix_unorth_B_star_iv(n, dx, data_id, data_Y, data_orth_b_t):
    out = []
    for i in range(n):
        id_i = data_id[i]
        t = data_Y[id_i][:, 0]
        list_B_star_iv = []
        for v in range(dx):
            q = len(data_orth_b_t[v])
            list_knots = np.arange(1, q - 3) / (q - 3)
            B_star_t_iv = dmatrix("bs(x = t, knots = list_knots, \
                                  include_intercept = True, \
                                  lower_bound = 0, upper_bound = 1) - 1")
            list_B_star_iv.append(B_star_t_iv)
        out.append(list_B_star_iv)
    return out



# ### $\tilde{\mu}^*_{iv}$: fun_matrix_tilde_mu_star_iv

# In[86]:


def fun_matrix_tilde_mu_star_iv(n, dx, data_theta_mu, data_B_unorth_star_iv):
    out = []
    for i in range(n):
        B_star_i = data_B_unorth_star_iv[i]
        list_tilde_mu_star_iv = []
        for v in range(dx):
            B_star_iv = B_star_i[v]
            tilde_mu_star_iv = np.dot(B_star_iv, data_theta_mu[v])
            list_tilde_mu_star_iv.append(tilde_mu_star_iv)
        out.append(list_tilde_mu_star_iv)
    return out


# ### $\tilde{\mu}^*_{ic,v}$: fun_matrix_tilde_mu_star_ic_v

# In[87]:


def fun_matrix_tilde_mu_star_ic_v(n, C, dx, data_beta, data_tilde_mu_star_iv):
    out = []
    for i in range(n):
        tilde_mu_star_i = data_tilde_mu_star_iv[i]
        list_tilde_mu_star_ic = []
        for c in range(C):
            beta_cx = data_beta[c][1:dx + 1]
            list_tilde_mu_star_ic_v = []
            for v in range(dx):
                tilde_mu_star_iv = tilde_mu_star_i[v]
                tilde_mu_star_ic_v = tilde_mu_star_iv * beta_cx[v]
                list_tilde_mu_star_ic_v.append(tilde_mu_star_ic_v)
            list_tilde_mu_star_ic.append(list_tilde_mu_star_ic_v)
        out.append(list_tilde_mu_star_ic)
    return out


# ### $\tilde{\Psi}^*_{iv}$: fun_matrix_tilde_psi_star_iv

# In[88]:


def fun_matrix_tilde_psi_star_iv(n, dx, data_theta_psi, data_B_star_iv):
    out = []
    for i in range(n):
        B_star_i = data_B_star_iv[i]
        list_tilde_psi_star_iv = []
        for v in range(dx):
            B_star_iv = B_star_i[v]
            tilde_psi_star_iv = np.dot(B_star_iv, data_theta_psi[v])
            list_tilde_psi_star_iv.append(tilde_psi_star_iv)
        out.append(list_tilde_psi_star_iv)
    return out


# ### $\tilde{\Psi}^*_{ic,v}$: fun_matrix_tilde_psi_star_ic_v

# In[89]:


def fun_matrix_tilde_psi_star_ic_v(n, C, dx, data_beta, 
                                   data_tilde_psi_star_iv):
    out = []
    for i in range(n):
        tilde_psi_star_i = data_tilde_psi_star_iv[i]
        list_tilde_psi_star_ic = []
        for c in range(C):
            beta_cx = data_beta[c][1:dx + 1]
            list_tilde_psi_star_ic_v = []
            for v in range(dx):
                tilde_psi_star_iv = tilde_psi_star_i[v]
                tilde_psi_star_ic_v = tilde_psi_star_iv * beta_cx[v]
                list_tilde_psi_star_ic_v.append(tilde_psi_star_ic_v)
            list_tilde_psi_star_ic.append(list_tilde_psi_star_ic_v)
        out.append(list_tilde_psi_star_ic)
    return out


# ## $\tilde{W_{iv}}$: fun_matrix_tilde_W_iv

# In[90]:


def fun_matrix_tilde_W_iv(n, dx, data_id, data_W, data_tilde_mu_iv):
    out = []
    for i in range(n):
        id_i = data_id[i]
        tilde_mu_i = data_tilde_mu_iv[i]
        list_tilde_W_iv = []
        for v in range(dx):
            W_iv = data_W[v][id_i][:, 1]
            tilde_W_iv = np.array([W_iv]).T - tilde_mu_i[v]
            list_tilde_W_iv.append(tilde_W_iv)
        out.append(list_tilde_W_iv)
    return out


# ## $\tilde{Y_{ic}}$: fun_matrix_tilde_Y_ic

# In[91]:


def fun_matrix_tilde_Y_ic(n, C, dz, data_id, data_Z, data_Y, data_beta, 
                          data_tilde_mu_star_ic_v):
    out = []
    for i in range(n):
        id_i = data_id[i]
        Y_i = data_Y[id_i][:, 1].reshape(-1, 1)
        m_iy = len(data_Y[id_i])
        list_tilde_Y_ic = []
        for c in range(C):
            beta_c = data_beta[c]
            beta_c0 = beta_c[0]
            beta_cz = beta_c[-dz:]
            cate = np.array([np.dot(data_Z[id_i], beta_cz)]).T
            fixed = sum(data_tilde_mu_star_ic_v[i][c])
            tilde_Y_ic = Y_i - beta_c0 - cate - fixed
            list_tilde_Y_ic.append(tilde_Y_ic)
        out.append(list_tilde_Y_ic)
    return out


# ## $G_{y, ic}$: fun_matrix_G_y_ic

# In[92]:


def fun_matrix_G_y_ic(n, C, data_id, data_Y, data_var_Y):
    out = []
    for i in range(n):
        id_i = data_id[i]
        m_iy = len(data_Y[id_i])
        ones_matrix = np.ones([m_iy, m_iy])
        var_y = np.identity(m_iy) * data_var_Y[-1]
        list_G_y_ic = []
        for c in range(C):
            G_y_ic = ones_matrix * data_var_Y[c] + var_y
            list_G_y_ic.append(G_y_ic)
        out.append(list_G_y_ic)
    return out


# ## $\Lambda_i$: fun_list_invert_lambda_i

# In[93]:


def fun_list_invert_lambda_i(n, dx, data_id, data_W, data_var_W):
    out = []
    for i in range(n):
        id_i = data_id[i]
        diag_U = [data_var_W[0]] * len(data_W[0][id_i])
        for v in range(1, dx):
            diag_U = diag_U + [data_var_W[v]] * len(data_W[v][id_i])
        invert_diag_U = 1 / np.array(diag_U)
        out.append(np.diag(invert_diag_U))
    return out


# # E-Step

# ## Definition Variables

# ### $\Omega_{ic}$: fun_matrix_omega_ic

# In[94]:


def fun_matrix_omega_ic(n, C, data_sigma, data_tilde_psi_iv, 
                        data_tilde_psi_star_ic_v, data_G_y_ic, data_invert_lambda_i):
    part1 = np.linalg.inv(data_sigma)
    out = []
    for i in range(n):
        tilde_psi_i = fun_diag_blocks(data_tilde_psi_iv[i])
        invert_lambda_i = data_invert_lambda_i[i]
        part2 = np.dot(np.dot(tilde_psi_i.T, invert_lambda_i), tilde_psi_i)
        list_omega_ic = []
        
        for c in range(C):
            G_y_ic = data_G_y_ic[i][c]
            tilde_psi_star_ic = np.hstack(data_tilde_psi_star_ic_v[i][c])
            part3 = np.dot(np.dot(tilde_psi_star_ic.T, np.linalg.inv(G_y_ic)), 
                           tilde_psi_star_ic)
            list_omega_ic.append(np.linalg.inv(part1 + part2 + part3))
        out.append(list_omega_ic)
        
    return out


# ### $\tilde{\xi}_{ic}$: fun_matrix_tilde_xi_ic

# In[95]:


def fun_matrix_tilde_xi_ic(n, C, data_tilde_psi_iv, 
                           data_tilde_psi_star_ic_v, data_tilde_W_iv, 
                           data_tilde_Y_ic, data_G_y_ic, data_invert_lambda_i, 
                           data_omega_ic):
    out = []
    for i in range(n):
        tilde_W_i = np.vstack(data_tilde_W_iv[i])
        invert_lambda_i = data_invert_lambda_i[i]
        tilde_psi_i = fun_diag_blocks(data_tilde_psi_iv[i])
        part1 = np.dot(np.dot(tilde_psi_i.T, invert_lambda_i), tilde_W_i)
        list_tilde_xi_ic = []
        
        for c in range(C):
            tilde_Y_ic = data_tilde_Y_ic[i][c]
            G_y_ic = data_G_y_ic[i][c]
            tilde_psi_star_ic = np.hstack(data_tilde_psi_star_ic_v[i][c])
            part2 = np.dot(np.dot(tilde_psi_star_ic.T, np.linalg.inv(G_y_ic)), 
                           tilde_Y_ic)
            list_tilde_xi_ic.append(np.dot(data_omega_ic[i][c], (part1 + part2)))
        out.append(list_tilde_xi_ic)
        #if i == 195:
         #   print('i:', i)
         #   print(part1)
         #   print(part2) 
    return out


# ### $\tilde{\Sigma}_{ic}$: fun_matrix_tilde_sigma_ic

# In[96]:


def fun_matrix_tilde_simga_ic(n, C, data_omega_ic, data_tilde_xi_ic):
    out = []
    for i in range(n):
        list_tilde_simga_ic = []
        for c in range(C):
            list_tilde_simga_ic.append(data_omega_ic[i][c] + np.dot(data_tilde_xi_ic[i][c], 
                                                                    data_tilde_xi_ic[i][c].T))
        out.append(list_tilde_simga_ic)
    return out


# ### $\tilde{\pi}_{ic}$: fun_matrix_tilde_pi

# In[97]:


def fun_tilde_pi(n, C, data_pi, data_tilde_W_iv, data_tilde_Y_ic, data_G_y_ic,
                 data_invert_lambda_i, data_tilde_xi_ic, data_omega_ic):
    out = []
    for i in range(n):
        pi_i = data_pi[i ] 

        list_temp = []
        for c in range(C):
            G_y_ic = data_G_y_ic[i][c]
            omega_ic = data_omega_ic[i][c]
            part1 = pi_i[c] * (np.linalg.det(G_y_ic)**(-1/2))* (np.linalg.det(omega_ic)**(1/2))

            tilde_Y_ic = data_tilde_Y_ic[i][c]
            part2_2 = np.dot(np.dot(tilde_Y_ic.T, np.linalg.inv(G_y_ic)),
                             tilde_Y_ic)
            
            tilde_xi_ic = data_tilde_xi_ic[i][c]
            part2_3 = np.dot(np.dot(tilde_xi_ic.T, np.linalg.inv(omega_ic)), 
                             tilde_xi_ic)
            
            part2 = (part2_2 - part2_3)[0, 0]
            
            list_temp.append(part1 * np.exp(part2 / (- 2)))
            
                    
        list_numerator = np.nan_to_num(list_temp)
        #denominator = sum(list_numerator)
        denominator = sum(list_numerator) if sum(list_numerator) != 0 else 1
        out.append(list_numerator / denominator)

        
    return np.vstack(out)


# #### $\Omega_{i}$: fun_list_omega_i

# In[98]:


def fun_list_omega_i(n, C, data_omega_ic, data_tilde_pi):
    out = []
    for i in range(n):
        out_i = 0
        for c in range(C):
            out_i = out_i + data_tilde_pi[i][c] * data_omega_ic[i][c] 
        out.append(out_i)
    return out


# #### $\tilde{\xi}_i$: fun_list_tilde_xi_i

# In[99]:


def fun_list_tilde_xi_i(n, C, data_tilde_xi_ic, data_tilde_pi):
    out = []
    for i in range(n):
        out_i = 0
        for c in range(C):
            out_i = out_i + data_tilde_pi[i][c] * data_tilde_xi_ic[i][c] 
        out.append(out_i)
    return out


# #### $\tilde{\Sigma}_i$: fun_list_tilde_sigma_i

# In[100]:


def fun_list_tilde_sigma_i(n, C, data_tilde_sigma_ic, data_tilde_pi):
    out = []
    for i in range(n):
        out_i = 0
        for c in range(C):
            out_i = out_i + data_tilde_pi[i][c] * data_tilde_sigma_ic[i][c]
        out.append(out_i)
    return out


# ## Q-Functions

# ### Q2

# In[101]:


def fun_Q2(n, C, dx, data_id, data_tilde_psi_star_ic_v, data_tilde_Y_ic, data_G_y_ic, 
           data_omega_ic, data_tilde_xi_ic, data_tilde_pi, indices_pc_split):
    
    q2 = 0
    for i in range(n):
        id_i = data_id[i]
        
        for c in range(C):            
            list_tilde_psi_star_ic_v = data_tilde_psi_star_ic_v[i][c]
            G_y_ic = data_G_y_ic[i][c]
            inv_G_y_ic = np.linalg.inv(G_y_ic)
            det_G_y_ic = np.linalg.det(G_y_ic)
                        
            # part2_1
            tilde_Y_ic = data_tilde_Y_ic[i][c]
            m_y_i = len(tilde_Y_ic)
            # part1
            part1 = np.log(det_G_y_ic) + np.log(2 * np.pi) * m_y_i

            tilde_psi_star_ic = np.hstack(list_tilde_psi_star_ic_v)
            tilde_xi_ic = data_tilde_xi_ic[i][c]
            part2_1 = tilde_Y_ic - np.dot(tilde_psi_star_ic, tilde_xi_ic)
            
            # part2_2
            part2_2 = 0
            omega_ic = data_omega_ic[i][c]
            vsplit_omega_ic = np.vsplit(omega_ic, indices_pc_split)
            
            for vprime in range(dx):
                hsplit_omega_ic_vprime = np.hsplit(vsplit_omega_ic[vprime], 
                                                   indices_pc_split)
                for v in range(dx):
                    omega_ic_vprimev = hsplit_omega_ic_vprime[v]
                    
                    temp = np.dot(np.dot(list_tilde_psi_star_ic_v[v].T, inv_G_y_ic ),list_tilde_psi_star_ic_v[vprime])
        
                    part2_2 = part2_2 + np.trace(np.dot(temp, omega_ic_vprimev)) 
            
            part2 = np.dot(np.dot(part2_1.T, inv_G_y_ic), part2_1) + part2_2
            
            q2 = q2 + data_tilde_pi[i ][c] * (part1 + part2)
    print('Q2:',q2)

    return q2


# ### Q3

# In[102]:


def fun_Q3(n, dx, data_id, data_W, data_var_W, data_tilde_psi_iv, data_tilde_W_iv, 
           data_tilde_xi_i, data_tilde_sigma_i, indices_pc_split):
    
    q3 = 0
    for i in range(n):
        id_i = data_id[i]
        tilde_W_i = data_tilde_W_iv[i]
        tilde_xi_i = data_tilde_xi_i[i]
        split_tilde_xi_i = np.split(tilde_xi_i, indices_pc_split)
        tilde_sigma_i = data_tilde_sigma_i[i]
        vsplit_tilde_sigma_i = np.vsplit(tilde_sigma_i, indices_pc_split)
        
        for v in range(dx):
            # Part1
            part1 = len(data_W[v][id_i]) * np.log(data_var_W[v] * 2 * np.pi) 
            
            # part2
            tilde_W_iv = tilde_W_i[v]
            tilde_psi_iv = data_tilde_psi_iv[i][v]
            tilde_xi_iv = split_tilde_xi_i[v]
            
            hsplit_tilde_sigma_i_v = np.hsplit(vsplit_tilde_sigma_i[v], 
                                               indices_pc_split)
            tilde_sigma_i_vv = hsplit_tilde_sigma_i_v[v]
            
            temp = np.dot(tilde_psi_iv, tilde_xi_iv)
            
            temp_part2_1 = tilde_W_iv - temp
            part2_1 = np.dot(temp_part2_1.T, temp_part2_1)
            
            part2_2 = np.dot(temp.T, temp)
            
            part2_3 = np.trace(np.dot(np.dot(tilde_psi_iv.T, tilde_psi_iv), 
                                      tilde_sigma_i_vv))
            
            q3 =  q3 + part1 + (part2_1 + part2_3 - part2_2) / data_var_W[v]
    print('Q3:',q3)        
            
    return q3


# ### Q4

# In[103]:


def fun_Q4(data_sigma, data_tilde_sigma_i, list_pick_n_pc):
    
    n = len(data_tilde_sigma_i)
    
    temp = np.linalg.inv(data_sigma)
    
    q4 = n * np.log(np.linalg.det(data_sigma)) + n * np.sum(list_pick_n_pc) * np.log(2*np.pi)
    
    for i in range(n):
        q4 = q4 + np.trace(np.dot(temp, data_tilde_sigma_i[i])) 
    print('Q4:',q4)       
    return q4


# # M-Step

# ### $\mathbb{X}_{ic}$: fun_matrix_X_ic

# In[104]:


def fun_matrix_X_ic(n, C, dx, data_id, indices_pc_split, data_Z, data_tilde_mu_star_iv, 
                    data_tilde_psi_star_iv, data_tilde_xi_ic):
    out = []
    for i in range(n):
        
        id_i = data_id[i]
        
        list_X_ic = []
        for c in range(C):
            tilde_xi_ic = data_tilde_xi_ic[i][c]
            split_tilde_xi_ic = np.split(tilde_xi_ic, indices_pc_split)
    
            temp = []
            for v in range(dx):
                temp.append(data_tilde_mu_star_iv[i][v] + np.dot(data_tilde_psi_star_iv[i][v], 
                                                                 split_tilde_xi_ic[v]))
        
            X_ic = np.hstack(([[1]] * len(data_Z[id_i]), np.hstack(temp), data_Z[id_i]))
            
            list_X_ic.append(X_ic)
        out.append(list_X_ic)
        
    return out


# ### $A_{ic}$: fun_matrix_A_ic

# In[105]:


def fun_matrix_A_ic(n, C, dx, dz, data_id, data_Y, indices_pc_split, data_G_y_ic, 
                    data_tilde_psi_star_iv, data_omega_ic):
    out = []
    for i in range(n):
        id_i = data_id[i]
        m_y = len(data_Y[id_i])
        tilde_psi_star_i = data_tilde_psi_star_iv[i]
        
        list_A_ic = []
        for c in range(C):
            G_y_ic = data_G_y_ic[i][c]
            omega_ic = data_omega_ic[i][c]
            vsplit_omega_ic = np.vsplit(omega_ic, indices_pc_split)
    
    
            trace_matrix_0 = []
            trace_matrix_1 = []
            trace_matrix_2 = []
    
            for vprime in range(dx):
                hsplit_omega_ic_vprime = np.hsplit(vsplit_omega_ic[vprime], indices_pc_split)
        
                part_vprime = tilde_psi_star_i[vprime]
        
                row_trace_0 = []
                row_trace_1 = []
                row_trace_2 = []
                for v in range(dx):
                    omega_ic_vprimev = hsplit_omega_ic_vprime[v]
                    temp = np.dot(part_vprime, omega_ic_vprimev)

                    part_v_T = tilde_psi_star_i[v].T

                    row_trace_0.append(np.trace(np.dot(np.dot(part_v_T, np.linalg.inv(G_y_ic)), temp)))
                    row_trace_1.append(np.trace(np.dot(part_v_T, temp)))
                    row_trace_2.append(np.trace(np.dot(np.dot(part_v_T, np.ones((m_y, m_y))), temp)))


                trace_matrix_0.append(row_trace_0)
                trace_matrix_1.append(row_trace_1)
                trace_matrix_2.append(row_trace_2)
    
            list_diag_blocks_0 = [np.zeros((1, 1)), trace_matrix_0, np.zeros((dz, dz))]
            list_diag_blocks_1 = [np.zeros((1, 1)), trace_matrix_1, np.zeros((dz, dz))]
            list_diag_blocks_2 = [np.zeros((1, 1)), trace_matrix_2, np.zeros((dz, dz))]
            
            list_A_ic.append(list(map(fun_diag_blocks, [list_diag_blocks_0, 
                                                        list_diag_blocks_1, 
                                                        list_diag_blocks_2])))
        out.append(list_A_ic)
    
    return out


# ## Update Gamma

# ### Gradient

# In[106]:


def fun_gradient_gamma(n, data_id, data_Z, data_tilde_pi, data_gamma):
    
    out = 0
    for i in range(n):
        id_i = data_id[i]
        tilde_Z_i = np.append(1, data_Z[id_i][0])
        numerator = np.exp(np.dot(tilde_Z_i, data_gamma))
        #print(numerator)
        denominator = 1 + sum(numerator)
        
        out = out + (data_tilde_pi[i][:-1] - numerator / denominator) * np.array([tilde_Z_i]).T

    return -2 * out  


# ### Hessian Matrix

# In[107]:


def fun_hessian_gamma(n, data_id, data_Z, data_gamma):
    out = 0
    for i in range(n):
        id_i = data_id[i]
        tilde_Z_i = np.append(1, data_Z[id_i][0])
        part1 = np.array([tilde_Z_i]).T * tilde_Z_i
        
        temp = np.dot(tilde_Z_i, data_gamma)
        part2_1 = np.exp(temp)
        
        part2_2 = np.exp(2 * temp)
        
        part2_3 = 1 + sum(part2_1)
        
        part2 = (part2_1 * part2_3 - part2_2) / (part2_3 ** 2)
        
        out = out + np.array([part1 * j for j in part2])

        
    return 2 * out 


# ### fun_updata_gamma

# In[108]:


def fun_update_gamma(n, data_id, data_Z, data_tilde_pi, data_gamma):
    """
    data_Z: dict(int:np.2darray)
    data_tilde_pi: list/np.2darray
    data_gamma: list/np.2darray
    
    return: np.2darray    
"""
    
    for iterate in range(2):
        
        gradient_gamma = fun_gradient_gamma(n, data_id, data_Z, data_tilde_pi, data_gamma)
        hessian_gamma = fun_hessian_gamma(n, data_id, data_Z, data_gamma)
        
        diff = []
        for c in range(len(hessian_gamma)):
            diff.append(np.dot(np.linalg.inv(hessian_gamma[c]), 
                               np.array([gradient_gamma[:,c]]).T))
        
        data_gamma = data_gamma - np.hstack(diff)

    return data_gamma


# ## Update beta

# In[109]:


def fun_update_beta(n, C, dx, dz, data_id, data_Y, data_G_y_ic, data_tilde_pi, data_X_ic, data_A_ic):
    
    part1 = np.array([0])
    part2 = np.array([0])
    for i in range(n):
        id_i = data_id[i]
        Y_i = data_Y[id_i][:, 1]
        tilde_pi_i = data_tilde_pi[i]
        
        temp1 = []
        temp2 = []
        for c in range(C):
            X_ic = data_X_ic[i][c]
            A_ic = data_A_ic[i][c][0]
            
            inv_G_y_ic = np.linalg.inv(data_G_y_ic[i][c])
            temp1.append(tilde_pi_i[c] * (np.dot(np.dot(X_ic.T, inv_G_y_ic), X_ic) + A_ic))
            temp2.append(tilde_pi_i[c] * np.dot(np.dot(X_ic.T, inv_G_y_ic), Y_i))
        
        part1 = part1 + temp1
        part2 = part2 + temp2
        
    list_beta_c = []
    for c in range(C):
        list_beta_c.append(np.dot(np.linalg.inv(part1[c]), part2[c]))
        
    return np.vstack(list_beta_c)


# ## Update var_Y

# ### Gradient

# In[110]:


def fun_gradient_var_Y_e(n, C, data_id, data_Y, data_var_Y, data_beta, data_tilde_pi, data_X_ic, data_A_ic):
    
    numerator, denominator = 0, 0
    for i in range(n):
        id_i = data_id[i]
        Y_i = data_Y[id_i][:, 1]
        m_y_i = len(Y_i)
        var_Y_e = data_var_Y[-1]
        part0 = m_y_i / var_Y_e
        
        for c in range(C):
            part1_1 = var_Y_e + m_y_i * data_var_Y[c]
            part1_2 = part1_1 ** 2
            part1_3 = data_var_Y[c] * (2 * var_Y_e + m_y_i * data_var_Y[c]) /(var_Y_e**2 * part1_2)
            
            part_y_1 = Y_i - np.dot(data_X_ic[i][c], data_beta[c])
            #part_y_2 = np.dot(part_y_1, part_y_1)
            part_y_2 = sum(part_y_1 ** 2)
            #part_y_3 = np.dot(np.dot(part_y_1, np.ones((m_y_i, m_y_i))), part_y_1)
            part_y_3 = sum(part_y_1) ** 2
            
            
            part_a_1 = np.dot(np.dot(data_beta[c], data_A_ic[i][c][1]), data_beta[c])
            part_a_2 = np.dot(np.dot(data_beta[c], data_A_ic[i][c][2]), data_beta[c])
            
            num_part1 = data_var_Y[c] * ( - part0) / part1_1
            num_part2 = part0 - (part_y_2 + part_a_1)/ (var_Y_e **2)
            num_part3 = part1_3 * (part_a_2 + part_y_3)
            
            numerator = numerator + data_tilde_pi[i][c] * (num_part1 + num_part2 + num_part3)
            
            temp = data_var_Y[c] / (var_Y_e **3 * part1_2) - (part1_1 + var_Y_e) * part1_3 /(part1_1 * var_Y_e)
            den_part1 = part1_3 * m_y_i
            den_part2 = - part0/var_Y_e + 2 * (part_y_2 + part_a_1) / (var_Y_e **3)
            den_part3 = 2 * temp * (part_a_2 + part_y_3) 
            
            denominator = denominator + data_tilde_pi[i][c] * (den_part1 + den_part2 + den_part3)
    #print('gradient:', numerator)
    #print('hessian:', denominator)
    return numerator / denominator


# In[111]:


def fun_update_var_Y(n, C, data_id, data_Y, data_var_Y, data_beta, data_tilde_pi, data_X_ic, data_A_ic):
    #print('input data_var_Y:', data_var_Y)
    #print('_______________________________________')
    
     #update_var_Y_e
    for iterate in range(1):
        #print('iterate:', iterate)
        #print('data_var_Y:', data_var_Y)
        gradient_var_Y_e = fun_gradient_var_Y_e(n, C, data_id, data_Y, data_var_Y, data_beta, 
                                                data_tilde_pi, data_X_ic, data_A_ic)
        #print('gradient_var_Y_e:', gradient_var_Y_e)
        data_var_Y[-1] = data_var_Y[-1] - gradient_var_Y_e
       
        
    # update_var_Y_b
    numerator, denominator = np.array([0]), np.array([0])
    for i in range(n):
        id_i = data_id[i]
        Y_i = data_Y[id_i][:, 1]
        m_y_i = len(Y_i)
        var_Y_e = data_var_Y[-1]
        part0 = m_y_i * var_Y_e
        
        list_numerator = []
        list_denominator = []
        for c in range(C):
            part_y_1 = Y_i - np.dot(data_X_ic[i][c], data_beta[c])
            #part_y_3 = np.dot(np.dot(part_y_1, np.ones((m_y_i, m_y_i))), part_y_1)
            part_y_3 = sum(part_y_1) ** 2
            
            part_a_2 = np.dot(np.dot(data_beta[c], data_A_ic[i][c][2]), data_beta[c])
            
            list_numerator.append(data_tilde_pi[i][c] * (part_a_2 + part_y_3 - part0))    
            list_denominator.append(data_tilde_pi[i][c] * (m_y_i**2))
        
        numerator = numerator + list_numerator
        denominator = denominator + list_denominator
    
    data_var_Y[:-1] = numerator / denominator
    
    return data_var_Y


# ## Update var_W

# In[112]:


def fun_update_var_W(n, dx, data_id, indices_pc_split, data_W, data_tilde_psi_iv, 
                     data_tilde_W_iv, data_tilde_xi_i, data_tilde_sigma_i):
    m_x, numerator = np.array(0), np.array(0)
    for i in range(n):
        id_i = data_id[i]
        tilde_W_i = data_tilde_W_iv[i]
        tilde_xi_i = data_tilde_xi_i[i]
        split_tilde_xi_i = np.split(tilde_xi_i, indices_pc_split)
        tilde_sigma_i = data_tilde_sigma_i[i]
        vsplit_tilde_sigma_i = np.vsplit(tilde_sigma_i, indices_pc_split)
        m_x_i, numerator_i = [], []
        for v in range(dx):
            m_x_i.append(len(data_W[v][id_i]))
            tilde_W_iv = tilde_W_i[v]
            tilde_psi_iv = data_tilde_psi_iv[i][v]
            tilde_xi_iv = split_tilde_xi_i[v]
            
            hsplit_tilde_sigma_i_v = np.hsplit(vsplit_tilde_sigma_i[v], indices_pc_split)
            tilde_sigma_i_vv = hsplit_tilde_sigma_i_v[v]
            
            temp = tilde_W_iv - np.dot(tilde_psi_iv, tilde_xi_iv)
            part1 = np.dot(temp.T, temp)[0, 0]
            
            part2_1 = np.dot(tilde_psi_iv.T, tilde_psi_iv)
            part2_2 = tilde_sigma_i_vv - np.dot(tilde_xi_iv, tilde_xi_iv.T)
            part2 = np.trace(np.dot(part2_1, part2_2))
            numerator_i.append(part1 + part2)
        
        m_x = m_x + m_x_i
        numerator = numerator + numerator_i
        
    return numerator / m_x


# ## Update theta_mu

# ### updata theta_mu_v

# In[113]:


def fun_update_theta_mu_v(v, n, C, dx, dz, data_id, indices_pc_split, data_W, data_Y, 
                          data_beta, data_var_W, data_G_y_ic, data_B_unorth_iv, data_B_unorth_star_iv,   
                          data_tilde_mu_star_ic_v, data_tilde_psi_iv, 
                          data_tilde_psi_star_ic_v, data_tilde_Y_ic,
                          data_tilde_xi_ic, data_tilde_pi, data_tilde_xi_i):
    
    part1 = 0
    part2 = 0
    for i in range(n):
        id_i = data_id[i]
        
        B_iv = data_B_unorth_iv[i][v]
        B_star_iv = data_B_unorth_star_iv[i][v]
        Y_i = np.array([data_Y[id_i][:, 1]]).T
        
        #part1_1
        part1_1 = np.dot(B_iv.T, B_iv) / data_var_W[v]
        
        W_iv = np.array([data_W[v][id_i][:, 1]]).T
        tilde_psi_iv = data_tilde_psi_iv[i][v]
        
        tilde_xi_i = data_tilde_xi_i[i]
        split_tilde_xi_i = np.split(tilde_xi_i, indices_pc_split)
        tilde_xi_i_v = split_tilde_xi_i[v]
        
        temp = W_iv - np.dot(tilde_psi_iv, tilde_xi_i_v)
        
        part2_1 = np.dot(B_iv.T, temp) / data_var_W[v]
        
        part1_2 = 0
        part2_2 = 0
        for c in range(C):
            beta_c0 = data_beta[c][0]
            beta_cx = data_beta[c][1 : dx + 1]
            beta_cz = data_beta[c][dx + 1 : dx + dz + 1]
            tilde_pi_i_c = data_tilde_pi[i][c]
            inv_G_y_ic = np.linalg.inv(data_G_y_ic[i][c])
            
            temp1 = tilde_pi_i_c * beta_cx[v] * np.dot(B_star_iv.T, inv_G_y_ic)        
            part1_2 = part1_2 + beta_cx[v] * np.dot(temp1, B_star_iv)
            
            
            part2_2_1 = data_tilde_Y_ic[i][c] + data_tilde_mu_star_ic_v[i][c][v]
            
            tilde_xi_ic = data_tilde_xi_ic[i][c]
            split_tilde_xi_ic = np.split(tilde_xi_ic, indices_pc_split)
            
            part2_2_2 = 0
            for vprime in range(dx):
                tilde_psi_star_ic_vprime = data_tilde_psi_star_ic_v[i][c][vprime]
                tilde_xi_ic_vprime = split_tilde_xi_ic[vprime]
                
                part2_2_2 = part2_2_2 + np.dot(tilde_psi_star_ic_vprime, tilde_xi_ic_vprime)
                
            
            part2_2 = part2_2 + np.dot(temp1, (part2_2_1 - part2_2_2))
        
        
        part1 = part1 + part1_1 + part1_2
        
        part2 = part2 + part2_1 + part2_2

        
    return np.dot(np.linalg.inv(part1), part2)


# In[114]:


def fun_update_theta_mu(n, C, dx, dz, data_id, indices_pc_split, data_W, data_Y, data_beta, data_var_W, data_G_y_ic,
                        data_B_iv, data_B_star_iv, data_tilde_mu_star_ic_v, data_tilde_psi_iv, 
                        data_tilde_psi_star_ic_v, data_tilde_Y_ic, data_tilde_xi_ic, 
                        data_tilde_pi, data_tilde_xi_i):
    
    out = []
    for v in range(dx):
        update_theta_mu_v = fun_update_theta_mu_v(v, n, C, dx, dz, data_id, indices_pc_split, data_W, data_Y, 
                                                  data_beta, data_var_W, data_G_y_ic, data_B_iv, data_B_star_iv, 
                                                  data_tilde_mu_star_ic_v, data_tilde_psi_iv, 
                                                  data_tilde_psi_star_ic_v, data_tilde_Y_ic, 
                                                  data_tilde_xi_ic, data_tilde_pi, data_tilde_xi_i)
        
        out.append(update_theta_mu_v)

    return out


# ## Update theta_psi

# ### Gradient

# In[115]:


def fun_gradient_tilde_theta_psi_v_k(v, k, n, C, dx, indices_pc_split, data_beta, data_var_W, data_G_y_ic, 
                                     data_B_iv, data_B_star_iv, data_tilde_psi_iv, 
                                     data_tilde_psi_star_ic_v, data_tilde_W_iv, data_tilde_Y_ic, 
                                     data_omega_ic, data_tilde_xi_ic, data_tilde_pi, 
                                     data_tilde_xi_i, data_tilde_sigma_i):
    
    part1 = 0
    part2 = 0        
    for i in range(n):
        
        #part1
        B_iv = data_B_iv[i][v]
        tilde_W_iv = data_tilde_W_iv[i][v]
        tilde_psi_iv = data_tilde_psi_iv[i][v]
        
        tilde_xi_i = data_tilde_xi_i[i]
        split_tilde_xi_i = np.split(tilde_xi_i, indices_pc_split)
        tilde_xi_i_v = split_tilde_xi_i[v]
        tilde_xi_i_v_k = tilde_xi_i_v[k]
        
        part1_1 = (tilde_W_iv - np.dot(tilde_psi_iv, tilde_xi_i_v)) * tilde_xi_i_v_k
        
        tilde_sigma_i = data_tilde_sigma_i[i]
        vsplit_tilde_sigma_i = np.vsplit(tilde_sigma_i, indices_pc_split)
        hsplit_tilde_sigma_i_v = np.hsplit(vsplit_tilde_sigma_i[v], indices_pc_split)
        tilde_sigma_i_vv = hsplit_tilde_sigma_i_v[v]
        #tilde_sigma_i_vv_k = np.array(tilde_sigma_i_vv[:, k]).T
        
        tilde_delta_i_vv_k = np.array([(tilde_sigma_i_vv - np.dot(tilde_xi_i_v, 
                                                                  tilde_xi_i_v.T))[:, k]]).T
        
        part1_2 = np.dot(tilde_psi_iv, tilde_delta_i_vv_k)
        
        part1 = part1 + np.dot(B_iv.T, (part1_1 - part1_2)) / data_var_W[v]
        
        
        B_star_iv = data_B_star_iv[i][v]
        
        for c in range(C):
            inv_G_y_ic = np.linalg.inv(data_G_y_ic[i][c])
            beta_cx = data_beta[c][1 : dx + 1]
            
            tilde_xi_ic = data_tilde_xi_ic[i][c]
            split_tilde_xi_ic = np.split(tilde_xi_ic, indices_pc_split)
            tilde_xi_ic_v = split_tilde_xi_ic[v]
            tilde_xi_ic_v_k = tilde_xi_ic_v[k]
            
            
            part2_1_1 = 0
            part2_2 = 0
            
            list_tilde_psi_star_ic_v = data_tilde_psi_star_ic_v[i][c]
            omega_ic = data_omega_ic[i][c]
            hsplit_omega_ic = np.hsplit(omega_ic, indices_pc_split)
            for vprime in range(dx):
                part2_1_1 = part2_1_1 + np.dot(list_tilde_psi_star_ic_v[vprime], 
                                               split_tilde_xi_ic[vprime])
                
                vsplit_omega_ic_v = np.vsplit(hsplit_omega_ic[v], indices_pc_split)
                omega_ic_vprimev = vsplit_omega_ic_v[vprime]
                omega_ic_vprimev_k = np.array([omega_ic_vprimev[:, k]]).T
                
                part2_2 = part2_2 + np.dot(list_tilde_psi_star_ic_v[vprime], 
                                           omega_ic_vprimev_k)
            
            
            part2_1 = (data_tilde_Y_ic[i][c] - part2_1_1) * tilde_xi_ic_v[k]
            
            part2_temp = beta_cx[v] * data_tilde_pi[i][c]
            
            part2 = part2 + np.dot(np.dot(B_star_iv.T, inv_G_y_ic), 
                                   (part2_1 - part2_2)) * part2_temp
            
    return (-2) * (part1 + part2)


# ### Hessian Matrix

# In[116]:


def fun_hessian_tilde_theta_psi_v_k(v, k, n, C, dx, indices_pc_split, data_beta, data_var_W, data_G_y_ic, 
                                    data_B_iv, data_B_star_iv, data_tilde_psi_iv, data_omega_ic, 
                                    data_tilde_xi_ic, data_tilde_pi, data_tilde_xi_i, data_tilde_sigma_i):
    part1, part2 = 0, 0
    for i in range(n):
        
        # part1
        B_iv = data_B_iv[i][v]
        
        tilde_sigma_i = data_tilde_sigma_i[i]
        vsplit_tilde_sigma_i = np.vsplit(tilde_sigma_i, indices_pc_split)
        hsplit_tilde_sigma_i_v = np.hsplit(vsplit_tilde_sigma_i[v], indices_pc_split)
        tilde_sigma_i_vv = hsplit_tilde_sigma_i_v[v]
        
        tilde_xi_i = data_tilde_xi_i[i]
        split_tilde_xi_i = np.split(tilde_xi_i, indices_pc_split)
        tilde_xi_i_v = split_tilde_xi_i[v]
        tilde_xi_i_v_k = tilde_xi_i_v[k]
        
        tilde_delta_i_vv = tilde_sigma_i_vv - np.dot(tilde_xi_i_v, tilde_xi_i_v.T)
        tilde_delta_i_vv_kk = tilde_delta_i_vv[k, k]
        
        
        part1 = part1 + np.dot(B_iv.T, B_iv) * (tilde_delta_i_vv_kk + tilde_xi_i_v_k ** 2) / data_var_W[v]
                
        
        # part2
        B_star_iv = data_B_star_iv[i][v]
        
        part2_temp = 0
        for c in range(C):
            inv_G_y_ic = np.linalg.inv(data_G_y_ic[i][c])
            tilde_pi_ic = data_tilde_pi[i][c]
            beta_cx = data_beta[c][1 : dx + 1]
            
            omega_ic = data_omega_ic[i][c]
            vsplit_omega_ic = np.vsplit(omega_ic, indices_pc_split)
            hsplit_omega_ic_v = np.hsplit(vsplit_omega_ic[v], indices_pc_split)
            omega_ic_vv = hsplit_omega_ic_v[v]
            omega_ic_vv_kk = omega_ic_vv[k, k]
            
            
            tilde_xi_ic = data_tilde_xi_ic[i][c]
            split_tilde_xi_ic = np.split(tilde_xi_ic, indices_pc_split)
            tilde_xi_ic_v = split_tilde_xi_ic[v]
            tilde_xi_ic_v_k = tilde_xi_ic_v[k]
            
            
            part2_temp = part2_temp + tilde_pi_ic * (beta_cx[v] ** 2) * (omega_ic_vv_kk + tilde_xi_ic_v_k ** 2)
        part2 = part2 + np.dot(np.dot(B_star_iv.T, inv_G_y_ic), B_star_iv) * part2_temp
        

        
    return 2 * (part1 + part2)


# In[117]:


def fun_update_tilde_theta_psi(n, C, dx, indices_pc_split, data_theta_psi, data_beta, data_var_W, data_G_y_ic, 
                               data_B_iv, data_B_star_iv, data_tilde_psi_iv, data_tilde_psi_star_ic_v, 
                               data_tilde_W_iv, data_tilde_Y_ic, data_omega_ic, data_tilde_xi_ic, 
                               data_tilde_pi, data_tilde_xi_i, data_tilde_sigma_i):
    
    n_pc = list(map(lambda data: data.shape[1], data_theta_psi))
    
    for iterate in range(2):
        
        new_theta_psi = []
        for v in range(dx):
            temp = []
            for k in range(n_pc[v]):
                part1 = fun_gradient_tilde_theta_psi_v_k(v, k, n, C, dx, indices_pc_split, 
                                                         data_beta, data_var_W, data_G_y_ic, 
                                                         data_B_iv, data_B_star_iv, 
                                                         data_tilde_psi_iv, data_tilde_psi_star_ic_v, 
                                                         data_tilde_W_iv, data_tilde_Y_ic, 
                                                         data_omega_ic, data_tilde_xi_ic,
                                                         data_tilde_pi, data_tilde_xi_i, 
                                                         data_tilde_sigma_i)
                
                part2 = fun_hessian_tilde_theta_psi_v_k(v, k, n, C, dx, indices_pc_split, 
                                                        data_beta, data_var_W, data_G_y_ic, 
                                                        data_B_iv, data_B_star_iv, 
                                                        data_tilde_psi_iv, data_omega_ic, 
                                                        data_tilde_xi_ic, data_tilde_pi, 
                                                        data_tilde_xi_i, data_tilde_sigma_i)
                
                temp.append(np.dot(np.linalg.inv(part2), part1))
            
            new_theta_psi.append(data_theta_psi[v] - np.hstack(temp))
            
        data_theta_psi = new_theta_psi
        
    return new_theta_psi


# ### hat_theta_psi

# In[118]:


def fun_hat_theta_psi(n, dx, indices_pc_split, data_tilde_sigma_i, data_tilde_theta_psi):
    
    list_num_pc_v = list(map(lambda data: data.shape[1], data_tilde_theta_psi))
    
    tilde_sigma = sum(data_tilde_sigma_i) / n
    split_tilde_sigma = list(map(lambda data: np.hsplit(data, indices_pc_split), 
                                 np.vsplit(tilde_sigma, indices_pc_split)))
    
    eig_value = []
    hat_theta_psi = []
    for v in range(dx):
        D_xi_v = np.dot(np.dot(data_tilde_theta_psi[v], split_tilde_sigma[v][v]), 
                        data_tilde_theta_psi[v].T)
    
        eig_value_v, hat_theta_psi_v = np.linalg.eigh(D_xi_v)
        eig_value.append(eig_value_v[-list_num_pc_v[v]:][::-1])
        hat_theta_psi.append(hat_theta_psi_v[:, -list_num_pc_v[v]:][:,::-1])
        
    return eig_value, hat_theta_psi


# ## Update Sigma

# In[119]:


def fun_update_sigma(n, dx, indices_pc_split, data_tilde_sigma_i,
                     data_tilde_theta_psi, data_hat_theta_psi, data_list_eig_value):
    
    temp = sum(data_tilde_sigma_i) / n
    vsplit_temp = np.vsplit(temp, indices_pc_split)
    
    out = []
    for v in range(dx):
        hsplit_temp_v = np.hsplit(vsplit_temp[v], indices_pc_split)
        part_v = np.dot(data_hat_theta_psi[v].T, data_tilde_theta_psi[v])
            
        row_sigma = []
        for vprime in range(dx):
            if v == vprime:
                sigma_vvprime = np.diag(data_list_eig_value[v])
            else:
                part_vprime = np.dot(data_tilde_theta_psi[vprime].T, data_hat_theta_psi[vprime])
            
                temp_vvprime = hsplit_temp_v[vprime]
            
                sigma_vvprime = np.dot(np.dot(part_v, temp_vvprime), part_vprime)
            
            row_sigma.append(sigma_vvprime)
        out.append(np.hstack(row_sigma))

    return np.vstack(out)


# ## Update pi

# In[120]:


def fun_update_pi(n, data_id, data_Z, data_gamma):
    
    out = []
    for i in range(n):
        id_i = data_id[i]
        tilde_Z_i = np.append(1, data_Z[id_i][0])
        numerator = np.nan_to_num(np.exp(np.dot(tilde_Z_i, data_gamma)))
        denominator = 1 + sum(numerator)
        
        out.append(np.append(numerator/denominator, 1 - sum(numerator/denominator)))
    
    return np.vstack(out)


def fun_data_likeli(n, C, data_pi, data_G_y_ic, data_tilde_Y_ic, data_tilde_W_iv, data_invert_lambda_i,
                   data_tilde_xi_ic, data_omega_ic, data_sigma):
    out = []
    
    for i in range(n):
        pi_i = data_pi[i]
        tilde_W_i = np.vstack(data_tilde_W_iv[i])
        
        invert_lambda_i = data_invert_lambda_i[i]
        
        temp = (np.linalg.det(data_sigma)**(-1/2)) * (np.linalg.det(invert_lambda_i)**(1/2))
        
        part2_1 = np.dot(np.dot(tilde_W_i.T, invert_lambda_i), tilde_W_i)
        
        list_temp = 0
        for c in range(C):
            G_y_ic = data_G_y_ic[i][c]
            omega_ic = data_omega_ic[i][c]
            part1 = pi_i[c] * (np.linalg.det(G_y_ic)**(-1/2))* (np.linalg.det(omega_ic)**(1/2))

            tilde_Y_ic = data_tilde_Y_ic[i][c]
            part2_2 = np.dot(np.dot(tilde_Y_ic.T, np.linalg.inv(G_y_ic)),
                             tilde_Y_ic)
            
            tilde_xi_ic = data_tilde_xi_ic[i][c]
            part2_3 = np.dot(np.dot(tilde_xi_ic.T, np.linalg.inv(omega_ic)), 
                             tilde_xi_ic)
            
            part2 = (part2_1 + part2_2 - part2_3)[0, 0]
            
            list_temp = list_temp + part1 * np.exp(part2 / (- 2)) * temp 
            
        out.append(list_temp)
        
    return np.ma.masked_invalid(np.log(out)).sum() * -2



# # Convergence

def fun_convergence(data_W, data_Z, data_Y, data_beta, data_pi, data_gamma, 
                    data_sigma, data_var_W, data_var_Y, data_orth_b_t, data_theta_mu, 
                    data_theta_psi):
    
    print('----------------------------Iterate 1:------------------------------')
    t0 = time.time()
    
    n = len(data_Y)
    C = len(data_beta)
    dx = len(data_W)
    data_id = list(data_Z.keys())
    dz = np.shape(data_Z[data_id[0]])[1]
    indices_pc_split = np.cumsum(list(map(lambda data: data.shape[1], 
                                          data_theta_psi[: -1])))
    
    # Define variable
    data_B_iv = fun_matrix_B_iv(n, dx, data_id, data_W, data_orth_b_t)
    data_B_unorth_iv = fun_matrix_unorth_B_iv(n, dx, data_id, data_W, data_orth_b_t)
    
    data_tilde_mu_iv = fun_matrix_tilde_mu_iv(n, dx, data_theta_mu, data_B_unorth_iv)
    data_tilde_psi_iv = fun_matrix_tilde_psi_iv(n, dx, data_theta_psi, data_B_iv)
    
    data_B_star_iv = fun_matrix_B_star_iv(n, dx, data_id, data_Y, data_orth_b_t)
    data_B_unorth_star_iv = fun_matrix_unorth_B_star_iv(n, dx, data_id, data_Y, data_orth_b_t)
    
    data_tilde_mu_star_iv = fun_matrix_tilde_mu_star_iv(n, dx, data_theta_mu, 
                                                        data_B_unorth_star_iv)
    data_tilde_mu_star_ic_v = fun_matrix_tilde_mu_star_ic_v(n, C, dx, data_beta, 
                                                            data_tilde_mu_star_iv)
    data_tilde_psi_star_iv = fun_matrix_tilde_psi_star_iv(n, dx, data_theta_psi,
                                                          data_B_star_iv)
    data_tilde_psi_star_ic_v = fun_matrix_tilde_psi_star_ic_v(n, C, dx, data_beta, 
                                                              data_tilde_psi_star_iv)

    data_tilde_W_iv = fun_matrix_tilde_W_iv(n, dx, data_id, data_W, data_tilde_mu_iv)
    
    data_tilde_Y_ic = fun_matrix_tilde_Y_ic(n, C, dz, data_id, data_Z, data_Y, 
                                            data_beta, data_tilde_mu_star_ic_v)
    data_G_y_ic = fun_matrix_G_y_ic(n, C, data_id, data_Y, data_var_Y)
    data_invert_lambda_i = fun_list_invert_lambda_i(n, dx, data_id, data_W, data_var_W)
    
    #E-step
    data_omega_ic = fun_matrix_omega_ic(n, C, data_sigma, data_tilde_psi_iv, 
                                        data_tilde_psi_star_ic_v, data_G_y_ic, 
                                        data_invert_lambda_i)
    data_tilde_xi_ic = fun_matrix_tilde_xi_ic(n, C, data_tilde_psi_iv, 
                                              data_tilde_psi_star_ic_v, data_tilde_W_iv, 
                                              data_tilde_Y_ic, data_G_y_ic,
                                              data_invert_lambda_i, data_omega_ic)
    
    data_like = fun_data_likeli(n, C, data_pi, data_G_y_ic, data_tilde_Y_ic, data_tilde_W_iv, data_invert_lambda_i, 
                               data_tilde_xi_ic, data_omega_ic, data_sigma)

    
    data_tilde_sigma_ic = fun_matrix_tilde_simga_ic(n, C, data_omega_ic, data_tilde_xi_ic)

    data_tilde_pi = fun_tilde_pi(n, C, data_pi, data_tilde_W_iv, data_tilde_Y_ic, 
                                 data_G_y_ic, data_invert_lambda_i, 
                                 data_tilde_xi_ic, data_omega_ic)
        
    data_omega_i = fun_list_omega_i(n, C, data_omega_ic, data_tilde_pi)
    data_tilde_xi_i = fun_list_tilde_xi_i(n, C, data_tilde_pi, data_tilde_xi_ic)
    data_tilde_sigma_i = fun_list_tilde_sigma_i(n, C, data_tilde_pi, data_tilde_sigma_ic)
    
    Q1 = sum(sum(data_tilde_pi * np.log(data_pi) * (-2)))
    Q2 = fun_Q2(n, C, dx, data_id, data_tilde_psi_star_ic_v, data_tilde_Y_ic, data_G_y_ic, 
                data_omega_ic, data_tilde_xi_ic, data_tilde_pi, indices_pc_split)
    Q3 = fun_Q3(n, dx, data_id, data_W, data_var_W, data_tilde_psi_iv, data_tilde_W_iv, 
                data_tilde_xi_i, data_tilde_sigma_i, indices_pc_split)
    Q4 = fun_Q4(data_sigma, data_tilde_sigma_i, list_pick_n_pc)
    
    Q = (Q1 + Q2 + Q3 + Q4)[0, 0]
    

   

    i = 1
    stop = False
    while not stop:
        data_X_ic = fun_matrix_X_ic(n, C, dx, data_id, indices_pc_split, data_Z, 
                                    data_tilde_mu_star_iv, data_tilde_psi_star_iv, data_tilde_xi_ic)
        data_A_ic = fun_matrix_A_ic(n, C, dx, dz, data_id, data_Y, indices_pc_split, 
                                    data_G_y_ic, data_tilde_psi_star_iv, data_omega_ic)
        # M-step
        update_gamma = fun_update_gamma(n, data_id, data_Z, data_tilde_pi, data_gamma)
        
        update_beta = fun_update_beta(n, C, dx, dz, data_id, data_Y, data_G_y_ic, 
                                      data_tilde_pi, data_X_ic, data_A_ic)
        
        update_var_Y = fun_update_var_Y(n, C, data_id, data_Y, data_var_Y, data_beta, 
                                        data_tilde_pi, data_X_ic, data_A_ic)

#        update_var_Y = fun_update_e(n, C, data_id, data_Y, data_var_Y, data_beta, 
 #                                       data_tilde_pi, data_X_ic, data_A_ic)       
        update_var_W = fun_update_var_W(n, dx, data_id, indices_pc_split, data_W, data_tilde_psi_iv, 
                                        data_tilde_W_iv, data_tilde_xi_i, data_tilde_sigma_i)
    
        update_theta_mu = fun_update_theta_mu(n, C, dx, dz, data_id, indices_pc_split, data_W, data_Y, 
                                              data_beta, data_var_W, data_G_y_ic,
                                              data_B_unorth_iv, data_B_unorth_star_iv, data_tilde_mu_star_ic_v, 
                                              data_tilde_psi_iv, data_tilde_psi_star_ic_v, 
                                              data_tilde_Y_ic, data_tilde_xi_ic, 
                                              data_tilde_pi, data_tilde_xi_i)
        
        data_tilde_theta_psi = fun_update_tilde_theta_psi(n, C, dx, indices_pc_split, data_theta_psi, 
                                                          data_beta, data_var_W, data_G_y_ic, data_B_iv, 
                                                          data_B_star_iv, data_tilde_psi_iv, 
                                                          data_tilde_psi_star_ic_v, data_tilde_W_iv, 
                                                          data_tilde_Y_ic, data_omega_ic, data_tilde_xi_ic, 
                                                          data_tilde_pi, data_tilde_xi_i, data_tilde_sigma_i)

        data_list_eig_value, data_hat_theta_psi = fun_hat_theta_psi(n, dx, indices_pc_split, 
                                                                    data_tilde_sigma_i, data_tilde_theta_psi)
    
#        data_hat_theta_psi, data_tilde_xi_i = fun_check_sign(n, indices_pc_split, data_tilde_xi_i, 
#                                                              data_orth_b_t, data_hat_theta_psi)
    
        tilde_sigma = sum(data_tilde_sigma_i) / n
    
        update_sigma = fun_update_sigma(n, dx, indices_pc_split, data_tilde_sigma_i,
                                        data_tilde_theta_psi, data_hat_theta_psi, data_list_eig_value)
        
        update_pi = fun_update_pi(n, data_id, data_Z, data_gamma)
    
        # Convergence 2
        criteria_beta = (abs(update_beta - data_beta) / (abs(np.array(data_beta)) + 0.001)).max()
        
        criteria_gamma = (abs(update_gamma - data_gamma) / (abs(np.array(data_gamma)) + 0.001)).max()
        
        data_theta = np.hstack((np.hstack(data_theta_mu), np.hstack(data_theta_psi)))
        update_theta = np.hstack((np.hstack(update_theta_mu), np.hstack(data_hat_theta_psi)))
        criteria_theta = (abs(update_theta - data_theta) / (abs(np.array(data_theta)) + 0.001)).max()
        
        criteria_2 = max(criteria_beta, criteria_theta)        
 
        
        
        data_pi = update_pi
        data_gamma = update_gamma
        data_beta = update_beta
        data_var_Y = update_var_Y
        data_var_W = update_var_W
        data_theta_mu = update_theta_mu
        data_theta_psi = data_hat_theta_psi
        data_sigma = update_sigma
        data_tilde_sigma = tilde_sigma
        
        
        t1 = time.time()
        print('Iterate {} run time:'.format(i), t1 - t0)
        i = i + 1
        print('----------------------------Iterate {}:------------------------------'.format(i))
        t0 = time.time()
            
        # Define variable
        data_tilde_mu_iv = fun_matrix_tilde_mu_iv(n, dx, data_theta_mu, data_B_unorth_iv)
        data_tilde_psi_iv = fun_matrix_tilde_psi_iv(n, dx, data_theta_psi, data_B_iv)

        data_tilde_mu_star_iv = fun_matrix_tilde_mu_star_iv(n, dx, data_theta_mu, data_B_unorth_star_iv)
        data_tilde_mu_star_ic_v = fun_matrix_tilde_mu_star_ic_v(n, C, dx, data_beta, data_tilde_mu_star_iv)
        data_tilde_psi_star_iv = fun_matrix_tilde_psi_star_iv(n, dx, data_theta_psi, data_B_star_iv)
        data_tilde_psi_star_ic_v = fun_matrix_tilde_psi_star_ic_v(n, C, dx, data_beta, data_tilde_psi_star_iv)

        data_tilde_W_iv = fun_matrix_tilde_W_iv(n, dx, data_id, data_W, data_tilde_mu_iv)
        data_tilde_Y_ic = fun_matrix_tilde_Y_ic(n, C, dz, data_id, data_Z, data_Y, data_beta, data_tilde_mu_star_ic_v)
        data_G_y_ic = fun_matrix_G_y_ic(n, C, data_id, data_Y, data_var_Y)
        data_invert_lambda_i = fun_list_invert_lambda_i(n, dx, data_id, data_W, data_var_W)

        #E-step
        data_omega_ic = fun_matrix_omega_ic(n, C, data_sigma, data_tilde_psi_iv, 
                                            data_tilde_psi_star_ic_v, data_G_y_ic, 
                                            data_invert_lambda_i)
        data_tilde_xi_ic = fun_matrix_tilde_xi_ic(n, C, data_tilde_psi_iv, 
                                                  data_tilde_psi_star_ic_v, data_tilde_W_iv, 
                                                  data_tilde_Y_ic, data_G_y_ic,
                                                  data_invert_lambda_i, data_omega_ic)
        
        log_like = fun_data_likeli(n, C, data_pi, data_G_y_ic, data_tilde_Y_ic, data_tilde_W_iv, data_invert_lambda_i, 
                               data_tilde_xi_ic, data_omega_ic, data_sigma)
            
        data_tilde_sigma_ic = fun_matrix_tilde_simga_ic(n, C, data_omega_ic, data_tilde_xi_ic)
        
        
        data_tilde_pi = fun_tilde_pi(n, C, data_pi, data_tilde_W_iv, data_tilde_Y_ic, 
                                     data_G_y_ic, data_invert_lambda_i, 
                                     data_tilde_xi_ic, data_omega_ic)
        
        data_omega_i = fun_list_omega_i(n, C, data_omega_ic, data_tilde_pi)
        data_tilde_xi_i = fun_list_tilde_xi_i(n, C, data_tilde_pi, data_tilde_xi_ic)
        data_tilde_sigma_i = fun_list_tilde_sigma_i(n, C, data_tilde_pi, data_tilde_sigma_ic)
        
        Q1 = sum(sum(data_tilde_pi * np.log(data_pi) * (-2)))
        Q2 = fun_Q2(n, C, dx, data_id, data_tilde_psi_star_ic_v, data_tilde_Y_ic, data_G_y_ic, 
                    data_omega_ic, data_tilde_xi_ic, data_tilde_pi, indices_pc_split)
        Q3 = fun_Q3(n, dx, data_id, data_W, data_var_W, data_tilde_psi_iv, data_tilde_W_iv, 
                    data_tilde_xi_i, data_tilde_sigma_i, indices_pc_split)
        Q4 = fun_Q4(data_sigma, data_tilde_sigma_i, list_pick_n_pc)


        update_Q = (Q1 + Q2 + Q3 + Q4)[0, 0]
    
        # Convergence 1        
        criteria_1 = abs((update_Q - Q) / Q)
        
        Q = update_Q
         
        data_q = Q
        
        data_like = log_like
        
        stop = (np.nan_to_num(criteria_1)  < 0.0001) ^ (np.nan_to_num(criteria_2) < 0.005) ^ (i > 300)

    return data_gamma, data_beta, data_var_Y, data_var_W, data_theta_mu, data_theta_psi, data_sigma, data_tilde_xi_i, data_tilde_pi,data_q, data_like



# In[49]:


initial_sigma = np.diag([0.53, 0.03, 0.64, 0.03, 0.66, 0.05])
initial_gamma = np.array([[-1.57, -0.35, -0.05, -0.7, -0.1, -0.7]]).T
initial_beta = np.array([[1.26, 1.18, 0.54, -0.84, -0.02, -0.18, 0.23, -0.37, -0.21],
[-0.18, 0.04, -0.06, 0.02, -0.06, -0.05, -0.25, 0.23, -0.14]])

######################### Spline Number ######################
n_spline = 7
######################### b_t and orth_b_t ###################
b_t, orth_b_t = fun_b_t_N_orth_b_t(n_spline)
######################### list_basis #########################
dfbasis1 = pd.read_csv('SWAN/basis1.csv').iloc[:, 1:]
dfbasis2 = pd.read_csv('SWAN/basis2.csv').iloc[:, 1:]
dfbasis3 = pd.read_csv('SWAN/basis3.csv').iloc[:, 1:]
list_basis = [dfbasis1, dfbasis2, dfbasis3]
######################### list_orth_basis ####################
list_orth_basis = fun_orth_basis(list_basis, orth_b_t)

######################### list_original_theta_mu #############
original_dftheta_mu1 = pd.read_csv('SWAN/mu1.csv')[['x']]
original_dftheta_mu2 = pd.read_csv('SWAN/mu2.csv')[['x']]
original_dftheta_mu3 = pd.read_csv('SWAN/mu3.csv')[['x']]
list_original_theta_mu = [original_dftheta_mu1, original_dftheta_mu2, original_dftheta_mu3]

######################### list_theta_mu #############
list_theta_mu = fun_theta_mu(data_basis = list_basis, 
                             data_original_theta_mu = list_original_theta_mu)

######################### list_original_theta_psi #############
original_dftheta_psi1 = pd.read_csv('SWAN/psi1.csv').iloc[:, 1:]
original_dftheta_psi2 = pd.read_csv('SWAN/psi2.csv').iloc[:, 1:]
original_dftheta_psi3 = pd.read_csv('SWAN/psi3.csv').iloc[:, 1:]
list_original_theta_psi = [original_dftheta_psi1, original_dftheta_psi2, original_dftheta_psi3]
######################### list_pick_n_pc #############
list_pick_n_pc = [2, 2, 2]
######################### list_theta_psi #############
list_theta_psi = fun_theta_psi(data_orth_basis = list_orth_basis, 
                               data_original_theta_psi = list_original_theta_psi, 
                               data_sigma = initial_sigma, data_pick_n_pc = list_pick_n_pc)

######################### Variances #############
initial_var_W = [0.42, 0.32, 0.24]
initial_var_Y = [0.1, 0.9, 0.8, 0.2]


# In[50]:


result = []
n_repeat = 100
#for times in pbar(range(n_repeat)):
for times in range(n_repeat):   
    initial_var_Y = [0.9, 0.3, 0.2]
    print('times:', times)
    simu_X1measure = pd.read_csv('SWAN/W1/W1_{}.csv'.format(times + 1))
    simu_X2measure = pd.read_csv('SWAN/W2/W2_{}.csv'.format(times + 1))
    simu_X3measure = pd.read_csv('SWAN/W3/W3_{}.csv'.format(times + 1))
    simu_Ymeaure = pd.read_csv('SWAN/Y/Y_{}.csv'.format(times + 1))
    simu_probability = pd.read_csv('SWAN/probability2.csv').values[:,1:3]
    
    ###########################################################################
    ######################### Data maintenance ################################
    ###########################################################################
    
    ######################### Continuous Variables: W #########################
    dfW1 = simu_X1measure[['ID', 'xtime', 'W1']]
    dfW2 = simu_X2measure[['ID', 'xtime', 'W2']]
    dfW3 = simu_X3measure[['ID', 'xtime', 'W2']]
    # combination Dataframe Structure (list_dfW)
    list_dfW = [dfW1, dfW2, dfW3] 
    # combination Dictionary Structure (list_dictW)
    list_dictW = list(map(fun_df2dict, list_dfW))
    
    ######################### Categorical Variables: Z ########################
    # Remove the record with Ytime > 1
    simu_Ymeaure = simu_Ymeaure[simu_Ymeaure['Ytime'] <= 1]
    
    dfZ = simu_Ymeaure[['ID', 'Z1', 'Z2', 'black', 'asian','his']]
    # Dictionary Structure (dictZ)
    dictZ = fun_df2dict(dfZ)
    
    ######################### Response: Y #####################################
    dfY = simu_Ymeaure[['ID', 'Ytime', 'Y']]
    # Dictionary Structure (dictY)
    dictY = fun_df2dict(dfY)
    ######################### Initial Values ##################################
                                 
    data_W = list_dictW 
    data_Z = dictZ 
    data_Y = dictY 
    data_beta = initial_beta
    data_pi = simu_probability
    data_gamma = initial_gamma
    data_sigma = initial_sigma 
    var_W = initial_var_W
    var_Y = initial_var_Y
    data_b_t = b_t
    data_orth_b_t = orth_b_t 
    data_theta_mu = list_theta_mu
    data_theta_psi = list_theta_psi
    
    output = fun_convergence(data_W = list_dictW, data_Z = dictZ, data_Y = dictY, 
                data_beta = initial_beta, data_pi = simu_probability, data_gamma = initial_gamma, 
                data_sigma = initial_sigma, data_var_W = initial_var_W, data_var_Y = initial_var_Y,
                 data_orth_b_t = orth_b_t, 
                data_theta_mu = list_theta_mu, data_theta_psi = list_theta_psi)
    result.append(output)


# In[ ]:


### Export



df_result = pd.DataFrame(result, columns = ['data_gamma','data_beta', 'var_Y', 'var_W',
                                            'data_theta_mu', 'data_theta_psi',
                                            'data_sigma', 'data_tilde_xi_i', 'data_tilde_pi','data_q', 'data_like'])
dict_result = df_result.to_dict(orient='index')


def default(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    raise TypeError('Not serializable')

with open('result_2cluster_hpcc.txt','w') as fl:
    json.dump(dict_result, fl, default = default)

fl.closed

