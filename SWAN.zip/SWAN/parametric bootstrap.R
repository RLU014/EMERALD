N <- 3138
fit_score <- read.csv('fit_score.csv')[,-1]
fit_gamma <- read.csv('fit_gamma.csv')[,-1]
fit_beta <- read.csv('fit_beta.csv')[,-1]
coeff_mu <- read.csv('fit_mu.csv')[,-1]
coeff_psi <- read.csv('fit_psi.csv')[,-1]
library("splines")
set.seed(123)
t <- seq(0, 1, length.out = 1000)
basis<-bs(t,knots = (c(1:3)/4),intercept = T)
J <- t(basis)%*% basis / 1000
value <- eigen(J)$values
vector <- eigen(J)$vectors
orth_basis <- vector %*% diag(value^(-1/2))

#generate X1-glucose
simu_X1 <- function(t) {
  base <-bs(t,knots = (c(1:3)/4),intercept = T)
  mu1 <- base %*% coeff_mu[,1]
  psi11 <- base %*% orth_basis %*% coeff_psi[,1]
  psi12 <- base %*% orth_basis %*% coeff_psi[,2]
  return(cbind(mu1, psi11, psi12))
}

simu_W1 <- function(N, score) {
  xtime <- c()
  X1 <- c()
   for (i in 1:N) {
     time_i <- sort(runif(10, 0, 1))
     xtime <- append(xtime, time_i)
     mu1_i <- simu_X1(time_i)[, 1]
     psi11_i <- simu_X1(time_i)[, 2]
     psi12_i <- simu_X1(time_i)[, 3]
     X1_i <- mu1_i + score[i, 1] * psi11_i + score[i, 2] * psi12_i
     X1 <- append(X1, X1_i)
   }
  W1 <- X1 + rnorm(N*10, 0, sqrt(0.37))
  ID <- rep(1:N, each = 10)
  return(cbind(ID , xtime, X1, W1))
}

X1measure <- simu_W1(N, fit_score)

#tri
simu_X2 <- function(t) {
  base <-bs(t,knots = (c(1:3)/4),intercept = T)
  mu2 <- base %*% coeff_mu[,2]
  psi21 <- base %*% orth_basis %*% coeff_psi[,3]
  psi22 <- base %*% orth_basis %*% coeff_psi[,4]
  return(cbind(mu2, psi21, psi22))
}

simu_W2 <- function(N, score) {
  xtime <- c()
  X2 <- c()
  for (i in 1:N) {
    time_i <- sort(runif(10, 0, 1))
    xtime <- append(xtime, time_i)
    mu2_i <- simu_X2(time_i)[, 1]
    psi21_i <- simu_X2(time_i)[, 2]
    psi22_i <- simu_X2(time_i)[, 3]
    X2_i <- mu2_i + score[i, 3] * psi21_i + score[i, 4] * psi22_i
    X2 <- append(X2, X2_i)
  }
  W2 <- X2 + rnorm(N*10, 0, sqrt(0.275))
  ID <- rep(1:N, each = 10)
  return(cbind(ID, xtime, X2, W2))
}

X2measure <- simu_W2(N, fit_score)

#sys bp
simu_X3 <- function(t) {
  base <-bs(t,knots = (c(1:3)/4),intercept = T)
  mu3 <- base %*% coeff_mu[,3]
  psi31 <- base %*% orth_basis %*% coeff_psi[,5]
  psi32 <- base %*% orth_basis %*% coeff_psi[,6]
  return(cbind(mu3, psi31, psi32))
}

simu_W3 <- function(N, score) {
  xtime <- c()
  X3 <- c()
  for (i in 1:N) {
    time_i <- sort(runif(10, 0, 1))
    xtime <- append(xtime, time_i)
    mu3_i <- simu_X3(time_i)[, 1]
    psi31_i <- simu_X3(time_i)[, 2]
    psi32_i <- simu_X3(time_i)[, 3]
    X3_i <- mu3_i + score[i, 5] * psi31_i + score[i, 6] * psi32_i
    X3 <- append(X3, X3_i)
  }
  W3 <- X3 + rnorm(N*10, 0, sqrt(0.2917))
  ID <- rep(1:N, each = 10)
  return(cbind(ID, xtime, X3, W3))
}

X3measure <- simu_W3(N, fit_score)

Y <- read.csv('Ymeasure.csv')[,-1]
Z <- Y[, c('ID', 'Z1', 'Z2', 'black', 'asian','his' )]
library("dplyr")  
newZ <- Z %>% group_by(ID) %>% 
  distinct(Z1, Z2, black, asian, his)

Z <- as.matrix(cbind(rep(1, N) , newZ[, -1]))
fit_gamma <- as.matrix(fit_gamma)
fit_beta <- as.matrix(fit_beta)
sub_prob <- exp(as.matrix(Z) %*% as.matrix(fit_gamma))
prob <- matrix(0, nrow = N, ncol = 2)
label <- matrix(0, nrow = N, ncol = 2)
for (i in 1:N) {
  prob[i, 1] <- sub_prob[i, 1] / (rowSums(sub_prob)[i] + 1)
  prob[i, 2] <- 1 / (rowSums(sub_prob)[i] + 1)
  label[i, ] <- rmultinom(1, 1, prob = prob[i, ])
}
simu_label <- label %*% matrix(1:2, nrow = 2)

simu_Y <- function(N, gamma, beta, score) {
  Ytime <- c()
  Y_X1 <- c()
  Y_X2 <- c()
  Y_X3 <- c()
  Y <- c()
  for (i in 1:N) {
    time_i <- seq(0, 1, length.out = 10)
    Ytime <- append(Ytime, time_i)
    mu1_i <- simu_X1(time_i)[, 1]
    psi11_i <- simu_X1(time_i)[, 2]
    psi12_i <- simu_X1(time_i)[, 3]
    X1_i <- mu1_i + score[i, 1] * psi11_i + score[i, 2] * psi12_i
    Y_X1 <- append(Y_X1, X1_i)
    mu2_i <- simu_X2(time_i)[, 1]
    psi21_i <- simu_X2(time_i)[, 2]
    psi22_i <- simu_X2(time_i)[, 3]
    X2_i <- mu2_i + score[i, 3] * psi21_i + score[i, 4] * psi22_i
    Y_X2 <- append(Y_X2, X2_i)
    mu3_i <- simu_X3(time_i)[, 1]
    psi31_i <- simu_X3(time_i)[, 2]
    psi32_i <- simu_X3(time_i)[, 3]
    X3_i <- mu3_i + score[i, 5] * psi31_i + score[i, 6] * psi32_i
    Y_X3 <- append(Y_X3, X3_i)
  }
  return(cbind(Ytime, Y_X1, Y_X2, Y_X3))
}  

outw1 <- simu_W1(N, fit_score)
colnames(outw1) <- c('ID', 'xtime', 'X1', 'W1')


n_boot <- 200
for (i in 1:n_boot) {
  outw1 <- simu_W1(N, fit_score)
  colnames(outw1) <- c('ID', 'xtime', 'X1', 'W1')
  write.csv(outw1, file = paste0('W1/W1_', i,'.csv'))
}

for (i in 1:n_boot) {
  outw2 <- simu_W2(N, fit_score)
  colnames(outw2) <- c('ID', 'xtime', 'X2', 'W2')
  write.csv(outw2, file = paste0('W2/W2_', i,'.csv'))
}


for (i in 1:n_boot) {
  outw3 <- simu_W3(N, fit_score)
  colnames(outw3) <- c('ID', 'xtime', 'X2', 'W2')
  write.csv(outw3, file = paste0('W3/W3_', i,'.csv'))
}

for (j in 1:n_boot) {
  a <- simu_Y(N, fit_gamma, fit_beta, fit_score)
  temp <- cbind(rep(simu_label, each = 10), rep(Z[, 1], each = 10),
                a[,1], a[, 2], a[,3], a[, 4], rep(Z[,'Z1'], each = 10), 
                rep(Z[,'Z2'], each = 10), 
                rep(Z[,'black'], each = 10),
                rep(Z[,'asian'], each = 10),
                rep(Z[,'his'], each = 10)) 
  colnames(temp) <- c('Label', 'intercept', 'Ytime', 'Y_X1', 'Y_X2', 'Y_X3',
                      'Z1', 'Z2', 'black', 'asian', 'his')
  
  part1 <- temp[temp[, 'Label'] == 1, ]
  part2 <- temp[temp[, 'Label'] == 2, ]
  
  mix1 <- (part1[ , c('intercept','Y_X1', 'Y_X2', 'Y_X3',
                      'Z1', 'Z2', 'black', 'asian', 'his')]) %*% fit_beta[1, ] + rnorm(dim(part1)[1]/10, 0, sqrt(0.94))
  
  mix2 <- (part2[ , c('intercept','Y_X1', 'Y_X2', 'Y_X3',
                      'Z1', 'Z2', 'black', 'asian', 'his')]) %*% fit_beta[2, ] + rnorm(dim(part2)[1]/10, 0, sqrt(0.37))
  
  all <- rbind(cbind(part1, mix1), cbind(part2, mix2))
  bb <- all[, ncol(all)] + rnorm(N*10, 0, sqrt(0.25))
  dat <- data.frame(all, bb, rep(1:N, each = 10))
  colnames(dat)[14] <- 'ID'
  colnames(dat)[13] <- 'Y'
  write.csv(dat, file = paste0('Y/Y_', j,'.csv'))
}

